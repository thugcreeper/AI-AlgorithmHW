﻿
Partial Class cookie1
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name As String = "aaa"
        Response.Cookies("User").Value = Server.UrlEncode(name)
        Dim dtDay As Date = DateAdd("D", 10, Today)
        Response.Cookies("User").Expires = dtDay
        Label1.Text = "add cookie succssfully"

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("cookie2.aspx")
    End Sub
End Class
