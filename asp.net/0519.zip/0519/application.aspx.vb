﻿
Partial Class application
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Application("Page_Counter") IsNot Nothing Then
            Application.Lock()
            Application("Page_Counter") += 1
            Label1.Text = "網頁總登入次數" & Application("Page_Counter")
            Application.UnLock()
        Else
            Application.Lock()
            Application("Page_Counter") = 0
            Application.UnLock()
        End If

    End Sub
End Class
