﻿
Partial Class crossweb1
    Inherits System.Web.UI.Page

End Class
