﻿
Partial Class viewstate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim nick = "暱稱test"
        Dim name As String = "小名"
        If Page.IsPostBack Then
            Dim myNmae As String = ""
            If myNmae IsNot Nothing Then
                myNmae = ViewState("nickname")
            End If
            Label1.Text = myNmae & "/" & TextBox1.Text
        Else
            TextBox1.Text = name
            ViewState("nickname") = nick
        End If
    End Sub
End Class
