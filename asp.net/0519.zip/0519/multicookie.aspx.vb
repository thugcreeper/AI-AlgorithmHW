﻿
Partial Class multicookie
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'ㄎadd cookie
        Response.Cookies("User")("Name") = Server.UrlEncode(" 陳會安 ")
        Response.Cookies("User")("ID") = "1234"
        Response.Cookies("User").Expires = DateAdd("D", 10, Today)
        Label1.Text = "add cookies successfully"
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim name, id As String
        If Request.Cookies("User") IsNot Nothing Then
            name = Server.UrlDecode(Request.Cookies("User")("Name"))
            id = Request.Cookies("User")("ID")
            Label1.Text = "name:" & name & "<br>"
            Label1.Text &= "id" & id & "<br>"
        Else
            Label1.Text = "cookie不存在"
        End If
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim dtDay As Date = DateAdd("D", -365, Today)
        Response.Cookies("User").Expires = dtDay
        Label1.Text = "delete cookies successfully"
    End Sub
End Class
