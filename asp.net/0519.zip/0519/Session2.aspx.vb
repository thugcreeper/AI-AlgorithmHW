﻿
Partial Class Session2
    Inherits System.Web.UI.Page

    Sub checksession()
        Dim name, pswd As String
        If Session("UserName") IsNot Nothing Then
            name = Session("UserName")
            pswd = Session("UserPassword")
            Label1.Text = "session id:" & Session.SessionID & "<br>"
            Label1.Text &= "name:" & name & "<br>"
            Label1.Text &= "password:" & pswd & "<br>"
        Else
            Label1.Text = "session 不存在"
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        checksession()
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Session.Abandon()
        Label1.Text = "成功刪除session"
    End Sub
End Class
