﻿
Partial Class page1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name As String = TextBox1.Text
        Dim pswd As String = TextBox2.Text
        '中文要編碼
        Response.Redirect("page2.aspx?User=" & Server.UrlEncode(name) & "pswd=" & pswd)
    End Sub
End Class
