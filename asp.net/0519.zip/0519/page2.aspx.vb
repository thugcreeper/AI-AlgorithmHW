﻿
Partial Class page2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim user, pswd As String
        user = Server.UrlDecode(Request.QueryString("User"))
        pswd = Request.QueryString("pswd")
        Label1.Text = "username" & user & "<br>" & "password" & pswd
    End Sub
End Class
