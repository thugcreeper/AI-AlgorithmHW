﻿
Partial Class Session
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Session("UserName") = TextBox1.Text
        Session("UserPassword") = TextBox2.Text
        Response.Redirect("session2.aspx")
    End Sub
End Class
