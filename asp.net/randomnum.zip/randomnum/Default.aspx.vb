﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Function max(arr() As Integer) As Integer
        Dim i As Integer
        Dim maxnum As Integer = arr(0)
        For i = 1 To arr.Length - 1
            If (arr(i) > maxnum) Then
                maxnum = arr(i)
            End If
        Next
        Return maxnum
    End Function

    Function min(arr() As Integer) As Integer
        Dim i As Integer
        Dim minnum As Integer = arr(0)
        For i = 1 To arr.Length - 1
            If (arr(i) < minnum) Then
                minnum = arr(i)
            End If
        Next
        Return minnum
    End Function

    Function isprime(ByVal value As Integer) As Boolean
        Dim i As Integer
        If value = 1 Or value = 0 Then
            Return False
        End If
        For i = 2 To value
            If value Mod i = 0 And i < value Then
                Return False
            End If
        Next i
        Return True
    End Function

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num, i As Integer
        Dim arr(9) As Integer '0 - 9
        Dim counter As Integer = 0
        Dim occur(100) As Integer '0-100
        Dim maxnum, minnum As Integer
        For i = 0 To 10
            occur(i) = 0
        Next
        Do While counter < 10
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 100) + 1 '1~100
            arr(counter) = num
            occur(num) += 1
            counter += 1
            Label1.Text &= num & "<br>"
        Loop
        maxnum = max(arr)
        minnum = min(arr)
        Label1.Text &= "max=" & maxnum & "<br>"
        Label1.Text &= "min=" & minnum & "<br>"
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim num, i As Integer
        Dim arr(20) As Integer '0 - 19
        Dim counter As Integer = 0
        Dim occur(20) As Integer '0-100
        For i = 0 To 20
            occur(i) = 0
        Next
        Do While counter < 20
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 21) - 10 '-10~10
            arr(counter) = num
            occur(num + 10) += 1
            counter += 1
            'Label2.Text &= num & "<br>"
        Loop
        For i = 0 To occur.Length - 1
            Label2.Text &= i - 10 & "出現" & occur(i) & "次" & "<br>"
        Next
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim num, i As Integer
        Dim arr(4) As Integer '0 - 4
        Dim counter As Integer = 0
        Dim occur(9) As Integer '0-9
        For i = 0 To 9
            occur(i) = 0
        Next
        Do While counter < 5
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 10) + 1 '0-10
            If (occur(num - 1) = 0 And num Mod 2 = 1) Then
                arr(counter) = num
                occur(num - 1) += 1
                Label3.Text &= "(" & arr(counter) & ")"
                counter += 1
            End If
        Loop
        Label3.Text &= "<br>"
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim num, i As Integer
        Dim arr(9) As Integer '0 - 9
        Dim counter As Integer = 0
        Dim occur(100) As Integer '0-100
        For i = 0 To 100
            occur(i) = 0
        Next
        Do While counter < 10
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 100) + 1 '1-100
            If (occur(num) = 0 And isprime(num)) Then
                arr(counter) = num
                occur(num) += 1
                Label4.Text &= "(" & arr(counter) & ")"
                counter += 1
            End If
        Loop
        Label4.Text &= "is prime" & "<br>"
    End Sub
End Class
