﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class database1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim strDbcon, strSQL As String
        Dim objCon As SqlConnection
        Dim objCmd As SqlCommand
        Dim objDR As SqlDataReader
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                    "AttachDbFilename=" &
                    Server.MapPath("App_Data\School(6).mdf") &
                    ";Integrated Security=True"
        objCon = New SqlConnection(strDbcon) '連結database
        objCon.Open() 'open database
        strSQL = "SELECT * FROM Students" 'sql command
        objCmd = New SqlCommand(strSQL, objCon) '建立command物件的SQL指令
        objDR = objCmd.ExecuteReader() '取得datareader物件
        If objDR.HasRows Then
            Label1.Text = "資料表紀錄" & "<br/>"
            Do While objDR.Read()
                Label1.Text &= objDR("sid") & "-"
                Label1.Text &= objDR("name") & "-"
                Label1.Text &= objDR("tel") & "-"
                Label1.Text &= objDR("birthday") & "<br/>"
            Loop
        Else
            Label1.Text = "no data" & "<br/>"
        End If
        objDR.Close()
        objCon.Close() '關掉避免佔用memory
    End Sub
End Class
