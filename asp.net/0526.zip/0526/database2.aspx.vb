﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class database2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objcon As SqlConnection
        Dim objcmd As SqlCommand
        Dim strDbcon, strSQL As String
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                    "AttachDbFilename=" &
                    Server.MapPath("App_Data\School(6).mdf") &
                    ";Integrated Security=True"
        objcon = New SqlConnection(strDbcon) '連結database
        objcon.Open()
        strSQL = TextBox1.Text
        'strSQL="SELECT * FROM Students"
        objcmd = New SqlCommand(strSQL, objcon) '建立command物件的SQL指令
        Label1.Text = "Result:" & objcmd.ExecuteScalar() '取得一個欄位
        objcon.Close()
    End Sub
End Class
