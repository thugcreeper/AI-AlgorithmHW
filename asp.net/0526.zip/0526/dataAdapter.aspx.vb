﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class dataAdapter
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim objcon As SqlConnection
        Dim strDbcon, strSQL As String
        Dim objdatadp As SqlDataAdapter
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                    "AttachDbFilename=" &
                    Server.MapPath("App_Data\School(6).mdf") &
                    ";Integrated Security=True"
        objcon = New SqlConnection(strDbcon) '連結database
        objcon.Open()h
        strSQL = "SELECT * FROM Students"
        objdatadp = New SqlDataAdapter(strSQL, objcon)
        Dim objdataset As DataSet = New DataSet()
        objdatadp.Fill(objdataset, "students") 'students是別名
        Dim objRow As DataRow
        For Each objRow In objdataset.Tables("students").Rows
            Label1.Text &= objRow("sid") & " - "
            Label1.Text &= objRow("name") & " - "
            Label1.Text &= objRow("tel") & " - "
            Label1.Text &= objRow("birthday") & "<br/>"
        Next
        objcon.Close()
    End Sub
End Class
