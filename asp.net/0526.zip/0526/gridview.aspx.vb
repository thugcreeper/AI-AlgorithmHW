﻿
Partial Class gridview
    Inherits System.Web.UI.Page

End Class
