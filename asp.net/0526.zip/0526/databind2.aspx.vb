﻿
Partial Class databind2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ListBox1.SelectedIndex > -1 Then
            Label1.Text = " 選擇的學號 : " & ListBox1.SelectedItem.Value
        End If
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ListBox2.SelectedIndex > -1 Then
            Label2.Text = " 選擇的電話號碼 : " & ListBox2.SelectedItem.Value
        End If
    End Sub

End Class
