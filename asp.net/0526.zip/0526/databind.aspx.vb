﻿
Partial Class databind
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then '第一次載入
            Dim names As ArrayList = New ArrayList()
            names.Add(" 陳會安 ")
            names.Add(" 江小魚 ")
            names.Add(" 張無忌 ")
            names.Add(" 陳允傑 ")
            ListBox1.DataSource = names '指定資料來源
            ListBox1.DataBind()
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ListBox1.SelectedIndex > -1 Then '有選擇
            Label1.Text = ListBox1.SelectedItem.Text
        End If
    End Sub
End Class
