﻿
Partial Class _Default
    Inherits System.Web.UI.Page
    Sub print(str As String)
        Label1.Text &= str
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        print("pageload觸發 <br>") '網頁已經載入記憶體時，產生此事件
    End Sub

    Private Sub _Default_PreInit(sender As Object, e As EventArgs) Handles Me.PreInit
        print("pageinit觸發 <br>") '當伺服器準備從資料夾載入 ASP.NET 網頁時，產生此事件
    End Sub


    Private Sub _Default_Unload(sender As Object, e As EventArgs) Handles Me.Unload
        print("unload觸發 <br>") '完全執行後產生
    End Sub

    Private Sub _Default_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
        print("prerender觸發 <br>") '在建立控制項前，產生此事件執行最後的控制項更新
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Panel1.Visible = True Then
            Panel1.Visible = False
        Else
            Panel1.Visible = True
        End If

    End Sub
    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs) Handles LinkButton1.Click
        Label2.Text = "link button <br>"
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label2.Text = "一般button <br>"
    End Sub
    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click
        Label2.Text = "img button <br>"
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Image1.ImageUrl = "test1.jpg"
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Image1.ImageUrl = "Pripyat.jfif"
    End Sub

End Class
