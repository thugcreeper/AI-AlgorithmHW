﻿
Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.Title = "onload & linkbutton"
        HyperLink1.NavigateUrl = "https://arcwiki.mcd.blue/%E9%A6%96%E9%A1%B5"
        HyperLink1.Text = "arc中文維基"
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox2.Text &= "身高=" & CDbl(TextBox3.Text) & vbNewLine '換行
        TextBox2.Text &= "體重=" & CDbl(TextBox4.Text) & vbNewLine
        TextBox2.Text &= "bmi= 懶得算" & vbNewLine
    End Sub
End Class
