﻿
Partial Class Q5
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num, i As Integer
        Dim counter As Integer = 0
        Dim occur(10) As Integer '0-10
        For i = 0 To 10
            occur(i) = 0
        Next
        Do While counter < 5
            Randomize()
            'rnd產生0-1的小數
            num = Int(Rnd() * 10) + 1
            If num Mod 2 = 1 And occur(num) = 0 Then
                Label1.Text &= "(" & num & ")"
                counter += 1
                occur(num) = 1
            End If

        Loop
        Label1.Text &= "<br>"
    End Sub
End Class
