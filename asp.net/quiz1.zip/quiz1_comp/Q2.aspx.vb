﻿
Partial Class Q2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim value, i, j, len As Integer
        i = 0
        j = 0
        len = 0
        value = CInt(TextBox1.Text)
        Dim digits(8) As Integer

        Do While (value > 0)
            digits(7 - i) = value Mod 10
            'Label1.Text &= digits(i) & "<br>"
            i += 1
            value \= 10 '整數除法
            'Label1.Text &= value & "<br>"
        Loop
        For i = 0 To 7
            If digits(i) > 0 Then
                len += 1
            End If
        Next
        For j = 0 To 7
            If len Mod 2 = 0 Then
                If (j Mod 2 = 0 And digits(7 - j) <> 0) Then
                    Label1.Text &= digits(7 - j)
                End If
            Else
                If (j Mod 2 = 1 And digits(7 - j) <> 0) Then
                    Label1.Text &= digits(7 - j)
                End If
            End If
        Next j

        'For j = 0 To 7 Step 1
        'Label1.Text &= digits(j) & " "
        'Next j
        Label1.Text &= "<br>"
    End Sub
End Class
