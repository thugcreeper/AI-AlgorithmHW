﻿
Partial Class Q1
    Inherits System.Web.UI.Page
    Function minday(a As Integer, b As Integer, c As Integer) As Integer
        Dim test As Integer = 1
        Do While (test Mod a <> 0) Or (test Mod b <> 0) Or (test Mod c <> 0)
            test += 1
        Loop
        Return test
    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, min As Integer
        a = CInt(TextBox1.Text)
        b = CInt(TextBox2.Text)
        c = CInt(TextBox3.Text)
        min = minday(a, b, c)
        Label1.Text = min & "天" & "<br>"
    End Sub
End Class
