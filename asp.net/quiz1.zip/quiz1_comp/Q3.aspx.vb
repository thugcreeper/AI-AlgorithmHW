﻿
Partial Class Q3
    Inherits System.Web.UI.Page
    Function find(maxvalue As Integer, a As Integer, b As Integer) As Integer
        Dim i, sum As Integer
        i = 0
        sum = 0
        maxvalue = CInt(TextBox1.Text)
        Do While (i <= maxvalue)
            If (i Mod a = b) Then
                Label1.Text &= "(" & i & ")"
                sum += i
            End If
            i += 1
        Loop
        Label1.Text &= "<br>除以" & a & "餘" & b & "的數字總和為" & sum & "<br>"
        Return sum
    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim maxvalue, a, b, sum As Integer
        a = 3
        b = 2
        sum = find(maxvalue, a, b)

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim maxvalue, a, b, sum As Integer
        a = 4
        b = 1
        sum = find(maxvalue, a, b)
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim maxvalue, a, b, c, d, sum, sum1 As Integer
        a = 3
        b = 2
        c = 4
        d = 1
        sum = find(maxvalue, a, b)
        sum1 = find(maxvalue, c, d)
        Label1.Text = sum - sum1 & "<br>"
    End Sub
    Function isprime(ByVal value As Integer) As Boolean
        Dim i As Integer
        If value = 1 Or value = 0 Then
            Return False
        End If
        For i = 2 To value
            If value Mod i = 0 And i < value Then
                Return False
            End If
        Next i
        Return True
    End Function
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim i, j, sum, maxvalue As Integer
        i = 0
        j = 0

        sum = 0
        maxvalue = CInt(TextBox1.Text)
        Dim prime(maxvalue) As Integer
        Do While (i <= maxvalue)
            If (i Mod 4 = 1) Then
                'Label1.Text &= "(" & i & ")"
                prime(j) = i
                j += 1
            End If
            i += 1
        Loop

        For i = 0 To prime.Length - 1
            If isprime(prime(i)) Then
                sum += prime(i)
            End If

        Next i
        Label1.Text &= "滿足條件(2)數字中所有質數總合" & sum
    End Sub
End Class
