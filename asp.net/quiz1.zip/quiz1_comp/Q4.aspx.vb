﻿
Partial Class Q4
    Inherits System.Web.UI.Page
    Protected Sub Unnamed1_Click(sender As Object, e As EventArgs) '平行
        Dim i, j, sp, counter2 As Integer
        sp = 10
        For i = 0 To 8 '0-10
            For counter2 = sp To 0 Step -1
                Label1.Text &= "&nbsp"
            Next
            sp -= 1
            For j = 0 To 9
                If i + j >= 9 Then
                    Label1.Text &= "O"

                Else
                    Label1.Text &= "X"
                End If
            Next j
            Label1.Text &= "<br>"
        Next i
    End Sub
    Protected Sub Unnamed2_Click(sender As Object, e As EventArgs) '舉
        Dim i, j As Integer
        For i = 0 To 9 '0-10
            For j = 0 To 10
                If i + j >= 11 And (i + j) Mod 2 = 1 Then
                    Label1.Text &= "O"
                ElseIf i + j >= 10 And (i + j) Mod 2 = 0 Then
                    Label1.Text &= "X"
                Else
                    Label1.Text &= "X"
                End If
            Next j
            Label1.Text &= "<br>"
        Next i
    End Sub
    Protected Sub Unnamed3_Click(sender As Object, e As EventArgs) '梯
        Dim i, j, counter2, sp, counter As Integer
        counter = 9
        sp = 10
        For i = 0 To 9 '0-10
            For counter2 = sp To 0 Step -1
                Label1.Text &= "&nbsp"
            Next
            sp -= 1
            If counter < 14 Then
                For j = 0 To counter
                    Label1.Text &= "O"

                Next j
            Else
                For j = 0 To counter
                    Label1.Text &= "X"
                Next j
            End If
            counter += 1
            Label1.Text &= "<br>"
        Next i
    End Sub

End Class
