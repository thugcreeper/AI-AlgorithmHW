﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            If TextBox1.Text <> "" Then
                Label1.Text = TextBox1.Text & " 歡迎進入網頁 !"
            End If
        Else '第一次載入網頁
            TextBox1.Text = " 江小魚 "
        End If
    End Sub
End Class
