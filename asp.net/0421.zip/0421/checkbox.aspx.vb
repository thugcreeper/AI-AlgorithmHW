﻿
Partial Class checkbox
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim count As Integer
        count = CInt(TextBox1.Text)
        Dim sum As Integer = 0
        If CheckBox1.Checked Then '紅茶
            sum += 20 * count
        End If
        If CheckBox2.Checked Then '奶茶
            sum += 30 * count
        End If
        If CheckBox3.Checked Then '綠茶
            sum += 25 * count
        End If
        Label1.Text = sum.ToString("C") '為字串加上貨幣單位
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RadioButton1.Checked Then
            Label2.Text = "買一個吐司"
        End If
        If RadioButton2.Checked Then
            Label2.Text = "買一個飯糰"
        End If
        If RadioButton3.Checked Then
            Label2.Text = "買一個小籠包"
        End If
        If RadioButton4.Checked Then
            Label2.Text = "買一個漢堡"
        End If
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If DropDownList1.SelectedIndex > -1 Then 'index start from 0
            Label3.Text = DropDownList1.SelectedItem.Text & DropDownList1.SelectedItem.Value
        End If
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click 'add
        DropDownList2.Items.Add(TextBox2.Text)
    End Sub
    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click 'remove
        DropDownList2.Items.Remove(TextBox2.Text)
    End Sub

    Protected Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click 'remove all
        DropDownList2.Items.Clear()
    End Sub
    Protected Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click 'remove first
        DropDownList2.Items.RemoveAt(0)
    End Sub
    Protected Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If DropDownList2.Items.Count > 0 Then
            DropDownList2.Items.RemoveAt(DropDownList2.Items.Count - 1)
        End If

    End Sub
    Protected Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim i As Integer
        Dim str As String = " "
        For i = 0 To ListBox1.Items.Count - 1
            If ListBox1.Items(i).Selected Then
                str = str & ListBox1.Items(i).Text & "<br>"
            End If
        Next
        Label4.Text = str
    End Sub


    Protected Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If CheckBox4.Checked Then
            ListBox2.Items.Add(CheckBox4.Text)
        End If
        If CheckBox5.Checked Then
            ListBox2.Items.Add(CheckBox5.Text)
        End If
        If CheckBox6.Checked Then
            ListBox2.Items.Add(CheckBox6.Text)
        End If
    End Sub
    Protected Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click '左移
        Dim tmp As String
        While ListBox4.SelectedIndex > -1
            tmp = ListBox4.SelectedItem.Text
            ListBox3.Items.Add(tmp)
            ListBox4.Items.Remove(ListBox4.SelectedItem)
        End While
    End Sub
    Protected Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click '右移
        Dim tmp As String
        While ListBox3.SelectedIndex > -1
            tmp = ListBox3.SelectedItem.Text
            ListBox4.Items.Add(tmp)
            ListBox3.Items.Remove(ListBox3.SelectedItem)
        End While
    End Sub
End Class
