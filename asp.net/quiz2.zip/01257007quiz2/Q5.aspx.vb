﻿
Partial Class Q5
    Inherits System.Web.UI.Page

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        If RadioButtonList1.SelectedItem.Text = "星期一" Then
            Label1.Text = "Monday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期二" Then
            Label1.Text = "Tuesday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期三" Then
            Label1.Text = "Wendesday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期四" Then
            Label1.Text = "Thursday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期五" Then
            Label1.Text = "Friday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期六" Then
            Label1.Text = "Saturday"
        ElseIf RadioButtonList1.SelectedItem.Text = "星期日" Then
            Label1.Text = "Sunday"
        End If
    End Sub
End Class
