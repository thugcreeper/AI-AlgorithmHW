﻿
Partial Class Q4
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sum As Integer = 0
        Dim count As Integer = 0
        If CheckBox1.Checked Then
            sum += 2500
            count += 1
        End If
        If CheckBox2.Checked Then
            sum += 3000
            count += 1
        End If
        If CheckBox3.Checked Then
            sum += 500
            count += 1
        End If
        If CheckBox4.Checked Then
            sum += 1000
            count += 1
        End If
        If CheckBox5.Checked Then
            sum += 5000
            count += 1
        End If
        If CheckBox6.Checked Then
            sum += 700
            count += 1
        End If
        If CheckBox7.Checked Then
            sum += 4000
            count += 1
        End If
        If CheckBox8.Checked Then
            sum += 600
            count += 1
        End If

        If RadioButton1.Checked Then
            sum *= 1.05
        ElseIf RadioButton2.Checked Then
            sum *= 1.1
        Else
            sum *= 1.15
        End If

        Label1.Text = "總價:" & sum.ToString("C") & "- 共" & count & "件物品" '為字串加上貨幣單位
    End Sub


End Class
