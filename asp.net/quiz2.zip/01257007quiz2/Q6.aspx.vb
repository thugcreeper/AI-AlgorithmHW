﻿
Partial Class Q6
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click '2左移1
        Dim tmp As String
        While ListBox2.SelectedIndex > -1
            tmp = ListBox2.SelectedItem.Text
            ListBox1.Items.Add(tmp)
            ListBox2.Items.Remove(tmp)
        End While
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click '1右移2
        Dim tmp As String
        While ListBox1.SelectedIndex > -1
            tmp = ListBox1.SelectedItem.Text
            ListBox2.Items.Add(tmp)
            ListBox1.Items.Remove(tmp)
        End While
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click '3左移2
        Dim tmp As String
        While ListBox3.SelectedIndex > -1
            tmp = ListBox3.SelectedItem.Text
            ListBox2.Items.Add(tmp)
            ListBox3.Items.Remove(tmp)
        End While
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click '2右移3
        Dim tmp As String
        While ListBox2.SelectedIndex > -1
            tmp = ListBox2.SelectedItem.Text
            ListBox3.Items.Add(tmp)
            ListBox2.Items.Remove(tmp)
        End While
    End Sub
End Class
