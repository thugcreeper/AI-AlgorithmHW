﻿
Partial Class Q2
    Inherits System.Web.UI.Page


    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        Const br = "<br/>"
        Dim hbc As HttpBrowserCapabilities = Request.Browser
        If DropDownList1.SelectedItem.Text = "瀏覽器種類" Then
            Label1.Text = hbc.Type
        ElseIf DropDownList1.SelectedItem.Text = "瀏覽器名稱" Then
            Label1.Text = hbc.Browser
        ElseIf DropDownList1.SelectedItem.Text = "瀏覽器版本" Then
            Label1.Text = hbc.Version
        ElseIf DropDownList1.SelectedItem.Text = "作業系統平台" Then
            Label1.Text = hbc.Platform
        Else
            Dim result As String = ""
            result &= "瀏覽器種類" & " = " & hbc.Type & br
            result &= "瀏覽器名稱" & " = " & hbc.Browser & br
            result &= "瀏覽器版本" & " = " & hbc.Version & br
            result &= "作業系統平台" & " = " & hbc.Platform & br
            Label1.Text = result
        End If
    End Sub
End Class
