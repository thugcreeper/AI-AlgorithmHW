﻿
Partial Class Q1aspx
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        '考試時沒做出來 掯
        Dim today As String = DateTime.Now.ToString("yyyy/MM/dd")

        If Page.IsPostBack Then
            If TextBox1.Text <> "" Then
                '考試時用雙引號，一直過不了
                Response.Write("您送出的留言為:[" & "<span style='color:blue;'>" & today & "</span>]" & "<span style='color:#CC0000;font-weight:bold;text-decoration:underline;'>" & " " & TextBox1.Text & "</span>]")
            End If
        Else
            TextBox1.Text = "請輸入留言"
        End If

    End Sub
End Class
'<span id="Label1" >Label</span>
