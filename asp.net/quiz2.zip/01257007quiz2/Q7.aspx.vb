﻿
Partial Class Q7
    Inherits System.Web.UI.Page

    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        If DropDownList1.SelectedValue = "校本部" Then
            DropDownList2.Items.Clear()
            DropDownList2.Items.Add("")
            DropDownList2.Items.Add("人文社會學院")
            DropDownList2.Items.Add("生命科學院")
        ElseIf DropDownList1.SelectedItem.Text = "濱海校區" Then
            DropDownList2.Items.Clear()
            DropDownList2.Items.Add("")
            DropDownList2.Items.Add("工學院")
            DropDownList2.Items.Add("電資學院")
        Else
            DropDownList2.Items.Clear()
            DropDownList3.Items.Clear()
        End If
    End Sub
    Protected Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList2.SelectedIndexChanged
        If DropDownList2.SelectedValue = "人文社會學院" Then
            DropDownList3.Items.Clear()
            DropDownList3.Items.Add("")
            DropDownList3.Items.Add("海洋文化研究所")
            DropDownList3.Items.Add("教育研究所")
        ElseIf DropDownList2.SelectedItem.Text = "生命科學院" Then
            DropDownList3.Items.Clear()
            DropDownList3.Items.Add("")
            DropDownList3.Items.Add("食品科學系")
            DropDownList3.Items.Add("水產養殖系")
        ElseIf DropDownList2.SelectedValue = "工學院" Then
            DropDownList3.Items.Clear()
            DropDownList3.Items.Add("")
            DropDownList3.Items.Add("材料工程研究所")
            DropDownList3.Items.Add("河海工程學系")
        ElseIf DropDownList2.SelectedItem.Text = "電資學院" Then
            DropDownList3.Items.Clear()
            DropDownList3.Items.Add("")
            DropDownList3.Items.Add("電機工程學系")
            DropDownList3.Items.Add("資訊工程學系")
        Else
            DropDownList3.Items.Clear()
        End If
    End Sub
End Class
