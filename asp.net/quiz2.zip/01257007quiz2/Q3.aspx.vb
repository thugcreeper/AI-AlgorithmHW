﻿
Partial Class Q3
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Page.IsValid Then
            Label1.Text = "使用者名稱=" & TextBox1.Text & "<br>" & "使用者密碼" & TextBox2.Text
        End If
    End Sub
End Class
