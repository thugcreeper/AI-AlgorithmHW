﻿
Partial Class printwithloop
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To 10
            For j = 0 To 10
                If (i + j > 6 And i + j <= 10) Then
                    Label1.Text &= "$"
                Else
                    Label1.Text &= "+"
                End If
            Next j
            Label1.Text &= "<br>"
        Next i
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim size As Integer = 9
        For i = 0 To size \ 2  'upper half
            For sp = 1 To size \ 2 - i
                Label2.Text &= "&nbsp;"
            Next sp
            For j = 1 To i * 2 + 1 Step 1

                Label2.Text &= "#"
            Next j
            For sp = 1 To size \ 2 - i
                Label2.Text &= "&nbsp;"
            Next sp
            Label2.Text &= "<br>"
        Next i

        For i = (size \ 2) - 1 To 0 Step -1 'upper half
            For sp = size \ 2 - i To 1 Step -1
                Label2.Text &= "&nbsp;"
            Next sp
            For j = i * 2 + 1 To 1 Step -1
                Label2.Text &= "#"
            Next j
            For sp = size \ 2 - i To 1 Step -1
                Label2.Text &= "&nbsp;"
            Next sp
            Label2.Text &= "<br>"
        Next i
    End Sub
End Class
