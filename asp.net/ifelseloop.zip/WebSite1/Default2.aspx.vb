﻿
Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim txt As String
        Dim i, sum As Integer
        sum = 0
        Dim value As Integer()
        txt = TextBox1.Text
        value = converttext(txt)
        For i = 0 To value.Length - 1
            sum += value(i)
        Next i
        Label1.Text = sum / value.Length
    End Sub

    Function converttext(txt As String) As Integer()
        Dim i As Integer
        Dim splitvalue() As String 'string array
        splitvalue = txt.Split()
        Dim value(splitvalue.Length - 1) As Integer
        For i = 0 To splitvalue.Length - 1
            value(i) = CInt(splitvalue(i))
        Next i
        Return value
    End Function
    Sub swap(ByRef a As Object, ByRef b As Object) 'call by ref
        Dim temp As Object = a
        a = b
        b = temp
    End Sub

    Function bubblesort(arr As Integer()) As Integer()
        Dim i, j As Integer
        For i = 0 To arr.Length - 2
            For j = 0 To arr.Length - i - 2
                If (arr(j) > arr(j + 1)) Then
                    swap(arr(j), arr(j + 1))
                End If
            Next j
        Next i
        Return arr
    End Function
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim txt As String
        Dim i As Integer
        Dim value As Integer()
        txt = TextBox2.Text
        value = converttext(txt)
        value = bubblesort(value)
        For i = 0 To value.Length - 1
            Label2.Text &= value(i) & "&nbsp"
        Next i
        Label2.Text &= "<br>"
    End Sub

    Function upper_half() As String '印出上三角
        Dim txt As String = "<hr>"
        For i = 0 To 10 Step 1
            For j = 0 To 10 Step 1
                If j < 10 - i Then
                    txt &= "&nbsp;"
                Else
                    txt &= "*"
                End If
            Next j
            txt &= "<br/>"
        Next i
        Return txt
    End Function

    Function lower_half() As String '印出下三角
        Dim txt As String
        For i = 0 To 10 Step 1
            For j = 10 To 0 Step -1
                If j >= 10 - i Then
                    txt &= "&nbsp;"
                Else
                    txt &= "*"
                End If
            Next j
            txt &= "<br/>"
        Next i
        Return txt
    End Function

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim txt As String
        txt = lower_half()
        Label3.Text &= txt
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim txt As String '菱形
        Label4.Text &= upper_half()
        Label4.Text &= lower_half()
    End Sub

    Function gcd(a As Integer, b As Integer)
        If (b = 0) Then
            Return a
        Else
            Return gcd(b, a Mod b)
        End If
    End Function

    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim value(0 To 1) As Integer 'size =2 (0,1)
        Dim txt = TextBox3.Text
        Dim ans As Integer
        value = converttext(txt)
        ans = gcd(value(0), value(1))
        Label5.Text = ans & " <br> "
    End Sub
End Class
