﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim value As Integer = 5
        If value = 1 Then
            Label1.Text &= " 星期日 <br/>"
        ElseIf value = 2 Then
            Label1.Text &= " 星期一 <br/>"
        ElseIf value = 3 Then
            Label1.Text &= " 星期二 <br/>"
        ElseIf value = 4 Then
            Label1.Text &= " 星期三 <br/>"
        ElseIf value = 5 Then
            Label1.Text &= " 星期四 <br/>"
        ElseIf value = 6 Then
            Label1.Text &= " 星期五 <br/>"
        ElseIf value = 7 Then
            Label1.Text &= " 星期六 <br/>"
        Else
            Label1.Text &= " WTF <br/>"
        End If

        Select Case value
            Case 1, 7
                Label1.Text &= " 假日 <br/>"
            Case 2 To 6
                Label1.Text &= " 工作日 <br/>"
            Case Else
                Label1.Text &= " unknown <br/>"
        End Select

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim product As Integer
        For i = 1 To 9 Step 1
            For j = 1 To 9 Step 1
                product = i * j
                Label2.Text &= j & " * " & i & " = " & product & " "
            Next j
            Label2.Text &= "<br/>"
        Next i
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim objName As New ArrayList
        Dim name As String
        objName.Add(" 陳會安 ")
        objName.Add(" 江小魚 ")
        objName.Add(" 陳允傑 ")
        objName.Add("assad")
        objName.Add("a-!@!#5d5ad")
        For Each name In objName
            Label3.Text &= name & “<br/>”
        Next
        objName.RemoveAt(1)
        objName.RemoveAt(3)
        Label3.Text &= "---------Remove---------" & "<br/>"
        For Each name In objName
            Label3.Text &= name & “<br/>”
        Next
    End Sub
    'Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load 'pageload會直接執行
    'For i = 0 To 10 Step 1
    'For j = 10 - i To 1 Step -1
    'Label4.Text &= "*"
    'Next j
    'Label4.Text &= "<br/>"
    'Next i
    'End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Label4.Text &= "<hr/>"
        For i = 0 To 10 Step 1
            For j = 0 To 10 Step 1
                If j <= 10 - i Then
                    Label4.Text &= "&nbsp;"
                Else
                    Label4.Text &= "*"
                End If
            Next j
            Label4.Text &= "<br/>"
        Next i
    End Sub
    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim counter As Integer = 1 'outer counter
        Dim counter2 As Integer  'inner counter
        Dim sum As Integer
        Do While counter <= 10
            sum = 0
            counter2 = 1
            Do
                sum += counter2
                counter2 += 1
            Loop Until counter2 > counter
            Label5.Text &= "1加到" & counter & "= &nbsp;"
            Label5.Text &= sum & "<br/>"
            counter += 1
        Loop
    End Sub

    Protected Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim num As Integer = CInt(TextBox1.Text)
        Dim sum As Integer = 0
        Dim counter As Integer = 0
        For counter = 0 To num
            If (num >= 3 And counter Mod 3 = 0) Then
                sum += counter
            End If
        Next
        Label6.Text &= sum & "<br/>"

    End Sub

End Class
