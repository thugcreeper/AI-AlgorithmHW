﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Q6
    Inherits System.Web.UI.Page

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Dim objcon As SqlConnection
        Dim strDbcon, strSQL As String
        Dim objdatadp As SqlDataAdapter
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                        "AttachDbFilename=" &
                        Server.MapPath("App_Data\School(6).mdf") &
                        ";Integrated Security=True"
        objcon = New SqlConnection(strDbcon) '連結database
        objcon.Open()
        Dim id As ArrayList = New ArrayList()
        Dim score As ArrayList = New ArrayList()
        If RadioButtonList1.SelectedItem.Text = "E001" Then
            strSQL = "SELECT * FROM Classes WHERE eid ='E001'"
            objdatadp = New SqlDataAdapter(strSQL, objcon)
            Dim objdataset As DataSet = New DataSet()
            objdatadp.Fill(objdataset, "students") 'students是別名

            Dim objRow As DataRow
            For Each objRow In objdataset.Tables("students").Rows
                id.Add(objRow("sid"))
                score.Add(objRow("grade"))
            Next
        ElseIf RadioButtonList1.SelectedItem.Text = "E002" Then
            strSQL = "SELECT * FROM Classes WHERE eid ='E002'"
            objdatadp = New SqlDataAdapter(strSQL, objcon)
            Dim objdataset As DataSet = New DataSet()
            objdatadp.Fill(objdataset, "students") 'students是別名

            Dim objRow As DataRow
            For Each objRow In objdataset.Tables("students").Rows
                id.Add(objRow("sid"))
                score.Add(objRow("grade"))
            Next

        ElseIf RadioButtonList1.SelectedItem.Text = "E003" Then
            strSQL = "SELECT * FROM Classes WHERE eid ='E003'"
            objdatadp = New SqlDataAdapter(strSQL, objcon)
            Dim objdataset As DataSet = New DataSet()
            objdatadp.Fill(objdataset, "students") 'students是別名

            Dim objRow As DataRow
            For Each objRow In objdataset.Tables("students").Rows
                id.Add(objRow("sid"))
                score.Add(objRow("grade"))
            Next

        End If
        GridView2.DataSource = ID
        GridView2.DataBind()
        GridView2.DataSource = score
        GridView2.DataBind()
    End Sub
End Class
