﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Q2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim objcon As SqlConnection
        Dim strDbcon, strSQL As String
        Dim objdatadp As SqlDataAdapter
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                    "AttachDbFilename=" &
                    Server.MapPath("App_Data\School(6).mdf") &
                    ";Integrated Security=True"
        objcon = New SqlConnection(strDbcon) '連結database
        objcon.Open()
        strSQL = "SELECT * FROM Instructors"
        objdatadp = New SqlDataAdapter(strSQL, objcon)
        Dim objdataset As DataSet = New DataSet()
        objdatadp.Fill(objdataset, "students") 'students是別名
        Dim objRow As DataRow
        For Each objRow In objdataset.Tables("students").Rows
            If (objRow("eid") Like "E002") Then
                Label1.Text &= ""
            Else
                Label1.Text &= objRow("eid") & " - "
                Label1.Text &= objRow("name") & " - "
                Label1.Text &= objRow("rank") & " - "
                Label1.Text &= objRow("department") & "<br/>"
            End If
        Next
        objcon.Close()
    End Sub
    Protected Sub SqlDataSource1_Selecting(sender As Object, e As SqlDataSourceSelectingEventArgs) Handles SqlDataSource1.Selecting

    End Sub
End Class
