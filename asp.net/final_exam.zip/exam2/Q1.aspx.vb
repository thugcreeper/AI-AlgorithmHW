﻿
Partial Class Q1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'add
        Response.Cookies("Name").Value = Server.UrlEncode("王洪賢")
        Response.Cookies("id").Value = Server.UrlEncode("01257007")
        Response.Cookies("mail").Value = Server.UrlEncode("01257007@ntou.edu.tw")
        Dim dtDay As Date = DateAdd("D", 10, Today) '10天后刪除
        Response.Cookies("Name").Expires = dtDay
        Response.Cookies("id").Expires = dtDay
        Response.Cookies("mail").Expires = dtDay
        Label1.Text = "成功建立cookies!"
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim name, id, mail As String

        name = Server.UrlDecode(Request.Cookies("Name").Value)
        id = Server.UrlDecode(Request.Cookies("id").Value)
        mail = Server.UrlDecode(Request.Cookies("mail").Value)

        If Request.Cookies("Name") IsNot Nothing And Request.Cookies("id") IsNot Nothing And Request.Cookies("mail") IsNot Nothing Then
            Dim info As ArrayList = New ArrayList()
            info.Add(name)
            info.Add(id)
            info.Add(mail)
            DropDownList1.DataSource = info '指定資料來源
            DropDownList1.DataBind()
        Else
            Label1.Text = "cookie不存在"
        End If
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click 'delete selected

        DropDownList1.ClearSelection()
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click 'delete all
        Dim dtDay As Date = DateAdd("D", -1, Today)
        Response.Cookies("Name").Expires = dtDay
        Response.Cookies("id").Expires = dtDay
        Response.Cookies("mail").Expires = dtDay
        Dim emptyarr As ArrayList = New ArrayList()
        DropDownList1.DataSource = emptyarr
        DropDownList1.DataBind()
        Label1.Text = "delete cookies successfully"
    End Sub
End Class
