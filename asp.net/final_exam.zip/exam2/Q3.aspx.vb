﻿
Partial Class Q3
    Inherits System.Web.UI.Page

    Protected Sub CustomValidator1_ServerValidate(source As Object, args As ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If args.Value.Contains("admin") Or args.Value.StartsWith("0") Or args.Value.EndsWith("1") Then
            args.IsValid = False
        Else
            args.IsValid = True
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Page.IsValid Then
            Label1.Text = TextBox1.Text
        End If
    End Sub
End Class
