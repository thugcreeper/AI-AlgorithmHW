﻿
Partial Class Q7
    Inherits System.Web.UI.Page

    Protected Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Const br = "<br/>"
        Dim hbc As HttpBrowserCapabilities = Request.Browser
        If ListBox1.SelectedItem.Text = "瀏覽器的名稱" Then
            TextBox1.Text = hbc.Browser
        ElseIf ListBox1.SelectedItem.Text = "主版本編號" Then
            TextBox1.Text = hbc.MajorVersion
        ElseIf ListBox1.SelectedItem.Text = "是否支援cookies" Then
            TextBox1.Text = hbc.Cookies
        ElseIf ListBox1.SelectedItem.Text = "是否支援JavaApplets" Then
            TextBox1.Text = hbc.JavaApplets
        Else
            Dim result As String = ""
            result &= "瀏覽器的名稱" & " = " & hbc.Browser & vbNewLine
            result &= "主版本編號" & " = " & hbc.MajorVersion & vbNewLine
            result &= "是否支援cookies" & " = " & hbc.Cookies & vbNewLine
            result &= "是否支援JavaApplets" & " = " & hbc.JavaApplets & vbNewLine
            TextBox1.Text = result
        End If
    End Sub
End Class
