﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Q4
    Inherits System.Web.UI.Page


    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Dim objcon As SqlConnection
        Dim strDbcon, strSQL As String
        Dim objdatadp As SqlDataAdapter
        strDbcon = "Data Source=(LocalDB)\MSSQLLocalDB;" &
                        "AttachDbFilename=" &
                        Server.MapPath("App_Data\School(6).mdf") &
                        ";Integrated Security=True"
        objcon = New SqlConnection(strDbcon) '連結database
        objcon.Open()

        If RadioButtonList1.SelectedItem.Text = "Students" Then

            strSQL = "SELECT * FROM Students"
            objdatadp = New SqlDataAdapter(strSQL, objcon)
            Dim objdataset As DataSet = New DataSet()
            objdatadp.Fill(objdataset, "students") 'students是別名
            Dim info As ArrayList = New ArrayList()

            Dim objRow As DataRow
            For Each objRow In objdataset.Tables("students").Rows
                info.Add(objRow("name"))
            Next
            ListBox1.Items.Clear()
            ListBox1.DataSource = info
            ListBox1.DataBind()
            objcon.Close()
        ElseIf RadioButtonList1.SelectedItem.Text = "Courses" Then

            strSQL = "SELECT * FROM Courses"
            objdatadp = New SqlDataAdapter(strSQL, objcon)
            Dim objdataset As DataSet = New DataSet()
            objdatadp.Fill(objdataset, "students") 'students是別名
            Dim info As ArrayList = New ArrayList()

            Dim objRow As DataRow
            For Each objRow In objdataset.Tables("students").Rows
                info.Add(objRow("title"))
            Next
            ListBox1.Items.Clear()
            ListBox1.DataSource = info
            ListBox1.DataBind()
            objcon.Close()
        End If
    End Sub

End Class
