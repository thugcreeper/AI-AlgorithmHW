﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Q5
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click '左移
        Dim tmp As String
        While ListBox2.SelectedIndex > -1
            tmp = ListBox2.SelectedItem.Text
            ListBox1.Items.Add(tmp)
            ListBox2.Items.Remove(tmp)
        End While
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim tmp As String
        While ListBox1.SelectedIndex > -1
            tmp = ListBox1.SelectedItem.Text
            ListBox2.Items.Add(tmp)
            ListBox1.Items.Remove(tmp)
        End While
    End Sub
End Class
