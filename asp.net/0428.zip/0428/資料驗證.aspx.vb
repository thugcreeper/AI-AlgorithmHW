﻿
Partial Class 資料驗證
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If IsValid Then
            Label1.Text = "name=" & TextBox1.Text & "password=" & TextBox2.Text
        End If
    End Sub
End Class
