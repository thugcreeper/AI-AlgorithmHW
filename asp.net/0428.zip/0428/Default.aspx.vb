﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged '記得auto postback屬性要改true
        Label2.Text = TextBox1.Text
    End Sub
    Protected Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        Label3.Text = RadioButton3.Text
    End Sub
    Protected Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        Label3.Text = RadioButton4.Text
    End Sub
    Protected Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        Label3.Text = RadioButton5.Text
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sum As Integer = 0
        If CheckBox1.Checked Then
            sum += 21000
        End If
        If CheckBox2.Checked Then
            sum += 22000
        End If
        If CheckBox3.Checked Then
            sum += 24000
        End If
        If CheckBox4.Checked Then
            sum += 26000
        End If
        If RadioButton1.Checked Then
            sum *= 1.05
        ElseIf RadioButton2.Checked Then
            sum *= 1.1
        End If

        Label1.Text = sum.ToString("C") '為字串加上貨幣單位
    End Sub
    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        If DropDownList1.SelectedValue = "工學院" Then
            DropDownList2.Items.Clear()
            DropDownList2.Items.Add("機械系")
            DropDownList2.Items.Add("河工系")
        ElseIf DropDownList1.SelectedItem.text = "電資學院" Then
            DropDownList2.Items.Clear()
            DropDownList2.Items.Add("資工系")
            DropDownList2.Items.Add("電機系")
        End If
        Label5.Text = DropDownList1.SelectedItem.Text
    End Sub
    Protected Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList2.SelectedIndexChanged
        Label5.Text = DropDownList1.SelectedItem.Text & "&nbsp;" & DropDownList2.SelectedItem.Text
    End Sub
End Class
