﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'declare variable
        ''error:Dim a, b As Integer = 6,8
        Dim a, b As Integer
        a = 6
        b = 8
        Dim b1 As Boolean = True
        Dim num1 As Byte = 254 'byte range:0-255
        Dim num2 As Short = 32767
        Dim num3 As Integer = 651655136
        Dim txt1 As String = "aaabbbccc"
        Dim obj1 '預設是object
        obj1 = "asda4485"
        Dim obj2 '預設是object
        obj2 = 15.822236
        Label1.Text = "boolean: " & b1.ToString() & "<br>" &
                      "byte: " & num1.ToString() & "<br>" &
                      "short: " & num2.ToString() & "<br>" &
                      "integer: " & num3.ToString() & "<br>" &
                      "string: " & txt1 & "<br>" &
                        "a= " & a & "b= " & b & "<br>" &
                        "obj1= " & obj1 & "<br>" &
                        "obj2= " & obj2 & "<br>"
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim score As Integer = CInt(TextBox1.Text) 'convert string to int
        If score > 80 Then
            Label2.Text &= "Score >80" & "<br>"
        ElseIf score > 60 And score < 80 Then
            Label2.Text &= "Score :60~80" & "<br>"
        Else
            Label2.Text &= "Score <60 come tomorrow year " & "<br>"
        End If
    End Sub
End Class
