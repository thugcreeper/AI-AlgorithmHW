﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 組件的一般資訊是由下列的屬性集 
' 控制。變更這些屬性值可修改與組件關聯的
' 資訊。

' 檢閱組件屬性的值
<Assembly: AssemblyTitle("WebApplication1")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("WebApplication1")>
<Assembly: AssemblyCopyright("Copyright ©  2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'下列 GUID 為專案公開 (Expose) 至 COM 時所要使用的 typelib ID
<Assembly: Guid("7d18e73e-3683-476c-bf3f-7361b01465b9")>

' 組件的版本資訊是由下列四項值構成:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' 您可以指定所有的值，也可以依照以下的方式，使用 '*' 將組建和修訂編號 
' 指定為預設值:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
