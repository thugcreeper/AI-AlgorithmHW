﻿
Partial Class recursion1
    Inherits System.Web.UI.Page

    Function Factorial(n As Integer) As Integer
        If n <= 1 Then
            Return 1
        End If
        Return Factorial(n - 1) * n
    End Function

    Sub hanoi(n As Integer, start As Char, goal As Char, other As Char) 'return -> sub
        If (n = 1) Then
            Label2.Text &= "move from " & start & "to" & goal & "<br>"
        Else
            hanoi(n - 1, start, other, goal)
            hanoi(1, start, goal, other)
            hanoi(n - 1, other, goal, start)
        End If
    End Sub

    Function gcd(a As Integer, b As Integer) As Integer
        If (b = 0) Then
            Return a
        Else
            Return gcd(b, a Mod b)
        End If
    End Function

    Function converttext(txt As String) As Integer()
        Dim i As Integer
        Dim splitvalue() As String 'string array
        splitvalue = txt.Split()
        Dim value(splitvalue.Length - 1) As Integer
        For i = 0 To splitvalue.Length - 1
            value(i) = CInt(splitvalue(i))
        Next i
        Return value
    End Function

    Function ackermann(m As Integer, n As Integer)
        If (m = 0) Then
            Return n + 1
        ElseIf (m > 0 And n = 0) Then
            Return ackermann(m - 1, 1)
        ElseIf (m > 0 And n > 0) Then
            Return ackermann(m - 1, ackermann(m, n - 1))
        End If
    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label1.Text &= Factorial(10)
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        hanoi(5, "a", "b", "c")
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim txt As String = textbox1.Text
        Dim numarr(0 To 1) As Integer
        Dim gcdnumber As Integer
        numarr = converttext(txt)
        If (numarr.Length) <> 2 Then
            Label3.Text &= "error, you must input only 2 number" & "<br>"
        Else
            gcdnumber = gcd(numarr(0), numarr(1))
            Label3.Text &= gcdnumber
        End If

    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim txt As String = TextBox2.Text
        Dim numarr(0 To 1) As Integer
        Dim ans As Integer
        numarr = converttext(txt)
        If (numarr.Length) <> 2 Then
            Label4.Text &= "error, you must input only 2 number" & "<br>"
        Else
            ans = ackermann(numarr(0), numarr(1))
            Label4.Text &= ans
        End If
    End Sub
End Class
