﻿
Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim grades(2) As Integer 'array宣告 0-2
        Dim grade2(0 To 2) As Integer 'array宣告
        Dim arr = {1, 5, 8, 96, -6, -41, 0} 'array宣告
        Dim name = {{"林XX", "陳XX"}, {"李XX", "黃XX"}, {"張XX", "王XX"}}
        Dim i, j As Integer
        For i = 0 To 6
            Label1.Text &= arr(i) & "<br>"
        Next i
        For i = 0 To 2
            For j = 0 To 1
                Label1.Text &= name(i, j)
            Next j
            Label1.Text &= "<br>"
        Next i
        ReDim Preserve arr(15) '延長array大小
        arr(8) = 3
        arr(9) = 43
        arr(10) = 78
        arr(14) = 7572
        Label1.Text &= "after preserve" & "<br>"
        For i = 0 To 14
            Label1.Text &= arr(i) & "<br>"
        Next i
    End Sub
    Sub add()
        Dim i, sum As Integer
        For i = 0 To 10
            Label2.Text &= i & ":" & "<br/>"
            sum += i
        Next i
        Label2.Text &= "sum=" & sum & "<br/>"
    End Sub
    Function Add2(n As Integer) As Integer
        Dim i, sum As Integer
        For i = 0 To n
            sum += i
        Next i
        Label2.Text &= "0 +...+ " & i - 1
        Label2.Text &= ",sum=" & sum & "<br/>"
        Return sum
    End Function
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sum As Integer
        add() 'call sub program
        Call add() 'call sub program
        sum = Add2(100)
    End Sub
    Sub myrandom()
        Dim num, occur(13), i As Integer
        Dim counter As Integer = 0
        For i = 0 To 13
            occur(i) = 0
        Next i
        While counter < 13
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 13) + 1 '1-13
            If occur(num) = 0 Then
                Label3.Text &= num & " "
                occur(num) = 1
                counter += 1
            End If

        End While

    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim i As Integer
        Label3.Text &= "產生13個1-13不重複的亂數"
        myrandom()
    End Sub
    Function isprime(ByVal value As Integer) As Boolean
        Dim i As Integer
        For i = 2 To value
            If value Mod i = 0 And i < value Then
                Return False
            End If
        Next i
        Return True
    End Function

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim value, i As Integer
        value = CInt(TextBox1.Text)
        If isprime(value) Then
            Label4.Text = value & " is prime"
        Else
            Label4.Text = value & " is not prime"
        End If
    End Sub
    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click, Button6.Click
        Dim card(1) As Integer
        Randomize()
        card(0) = Int(Rnd() * 13) + 1
        card(1) = Int(Rnd() * 13) + 1
        Dim btnbutton As Button
        btnbutton = CType(sender, Button)
        If btnbutton.ID = "Button5" Then
            Button5.Text = "*" & card(0) & "點"
            Button6.Text = card(1) & "點"
        ElseIf btnbutton.ID = "Button6" Then
            Button5.Text = card(0) & "點"
            Button6.Text = "*" & card(1) & "點"
        End If
    End Sub
    Protected Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim i, sum As Integer
        sum = 0
        For i = 0 To 10 Step 1
            If (i Mod 2 = 0) Then
                Continue For
            Else
                sum += i
            End If
        Next i

        Label5.Text = "1+~10的基數和為" & sum & "<br>"
    End Sub
End Class
