﻿
Partial Class Q5
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To 9
            If i < 5 Then
                For sp = 9 - i To 0 Step -1
                    Label1.Text &= "&nbsp;"
                Next sp
                For j = 0 To 9
                    If j > i Then
                        Label1.Text &= "X"
                    Else
                        Label1.Text &= "A"
                    End If

                Next j

                Label1.Text &= "<br>"
            Else
                For sp = 9 - i To 0 Step -1
                    Label1.Text &= "&nbsp;"
                Next sp

                For j = 0 To 9
                    If j < i + 1 Then
                        Label1.Text &= "B"
                    Else
                        Label1.Text &= "O"
                    End If

                Next j
                Label1.Text &= "<br>"
            End If

        Next i
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim size As Integer = 10

        For i = 0 To size
            If i < 5 Then
                For sp = 0 To i
                    Label1.Text &= "&nbsp;"
                Next sp
                For j = 9 To i Step -1
                    If (j > 3) Then
                        Label1.Text &= "S"
                    Else
                        Label1.Text &= "A"
                    End If
                Next j

                Label1.Text &= "<br>"
            Else
                For sp = 0 To i
                    Label1.Text &= "&nbsp;"
                Next sp
                For j = 9 To i Step -1
                    Label1.Text &= "8"
                Next j

                Label1.Text &= "<br>"
            End If

        Next i

    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        For i = 0 To 9
            If i < 4 Then
                For sp = 0 To i
                    Label1.Text &= "&nbsp;"
                Next sp
                For j = 19 To i Step -1
                    Label1.Text &= "A"
                Next j

                Label1.Text &= "<br>"
            Else
                For sp = 0 To i
                    Label1.Text &= "&nbsp;"
                Next sp
                For j = 13 - i To 0 Step -1
                    Label1.Text &= "O"
                Next j

                For k = 5 To 0 Step -1
                    Label1.Text &= "A"
                Next k
                Label1.Text &= "<br>"
            End If

        Next i
    End Sub

End Class
