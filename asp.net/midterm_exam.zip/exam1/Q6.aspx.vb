﻿
Partial Class Q6
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i As Integer
        Dim num As Double
        Dim arr(8) As Integer
        Dim counter As Integer = 0
        Dim occur(8) As Integer
        For i = 0 To 8
            occur(i) = 0
        Next
        Do While counter < 9
            Randomize() '打亂種子
            'rnd產生0-1的小數
            num = Int(Rnd() * 9) + 21
            If (occur(num Mod 20 - 1) = 0) Then
                occur(num Mod 20 - 1) += 1
                arr(counter) = num / 10
                counter += 1
                Label1.Text &= "(" & num / 10 & ")"
            End If
        Loop
        Label1.Text &= "<br>"
    End Sub
End Class
