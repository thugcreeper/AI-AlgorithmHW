﻿
Partial Class Q1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num As Integer
        Dim digit(0 To 3) As Integer
        num = CInt(TextBox1.Text)
        digit(0) = num \ 1000 '千
        digit(1) = (num \ 100) Mod 10 '百
        digit(2) = (num \ 10) Mod 10 '十
        digit(3) = num Mod 10 '各
        Dim acount, bcount As Integer
        acount = 0
        bcount = 0
        Dim ans(0 To 3) As Integer
        ans(0) = 6
        ans(1) = 7
        ans(2) = 3
        ans(3) = 2
        Dim i, j As Integer
        For i = 0 To 3
            If (digit(i) = ans(i)) Then
                acount += 1
            End If
        Next

        For i = 0 To 3
            For j = 0 To 3
                If (digit(j) = ans(i) And i <> j) Then
                    bcount += 1

                End If
            Next

        Next
        Label1.Text &= acount & "A" & bcount & "B" & "<br>"
    End Sub
End Class
