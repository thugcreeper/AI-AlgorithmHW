﻿
Partial Class Q2
    Inherits System.Web.UI.Page
    Function findcom(num As Integer) As Integer
        Dim i As Integer = 1
        Dim sum As Integer = 0
        For i = 1 To num - 1
            If num Mod i = 0 Then
                sum += i
            End If
        Next
        If (sum = num) Then
            Return num
        Else
            Return 0
        End If
    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim maxnum = CInt(TextBox1.Text)
        Dim i As Integer
        Dim ans As Integer
        Dim sum As Integer = 0
        For i = 0 To maxnum
            ans = findcom(i)
            If (ans <> 0) Then
                sum += ans
                Label1.Text &= "(" & ans & ")"
            End If
        Next

        Label1.Text &= "總和" & sum & "<br>"
    End Sub
End Class
