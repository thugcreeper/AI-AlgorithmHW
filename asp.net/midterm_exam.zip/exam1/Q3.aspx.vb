﻿
Partial Class Q3
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim input As Integer
        Dim arr(1000) As Integer
        Dim ansL As Integer = 0
        Dim counter As Integer = 0
        Dim current As Integer = 0
        input = CInt(TextBox1.Text)
        Do While input > 0
            current = input Mod 10
            If (current Mod 2 = 0) Then
                arr(counter) = current
                counter += 1
            End If
            input = input \ 10
        Loop
        For i = 0 To arr.Length - 1
            If arr(i) <> 0 Then
                ansL += 1

                'Label1.Text &= arr(i) & "<br>"
            End If
        Next

        Dim output(ansL) As Integer
        counter = 0
        For i = 0 To arr.Length - 1
            If arr(i) <> 0 Then
                output(counter) = arr(i)
                counter += 1
            End If
        Next
        For i = 0 To ansL - 1
            Label1.Text &= output(i)
        Next
        Label1.Text &= "<br>"
    End Sub
End Class
