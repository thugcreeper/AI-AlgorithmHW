﻿
Partial Class Q4
    Inherits System.Web.UI.Page

    Function Factorial(n As Integer) As Integer
        If n <= 1 Then
            Return 1
        End If
        Return Factorial(n - 1) * n
    End Function

    Function max(arr() As Integer) As Integer
        Dim i As Integer
        Dim maxnum As Integer = arr(0)
        For i = 1 To arr.Length - 1
            If (arr(i) > maxnum) Then
                maxnum = arr(i)
            End If
        Next
        Return maxnum
    End Function

    Function min(arr() As Integer) As Integer
        Dim i As Integer
        Dim minnum As Integer = arr(0)
        For i = 1 To arr.Length - 1
            If (arr(i) < minnum) Then
                minnum = arr(i)
            End If
        Next
        Return minnum
    End Function

    Function isprime(ByVal value As Integer) As Boolean
        Dim i As Integer
        If value = 1 Or value = 0 Then
            Return False
        End If
        For i = 2 To value
            If value Mod i = 0 And i < value Then
                Return False
            End If
        Next i
        Return True
    End Function

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sum As Long = 0
        For i = 1 To 9 Step 2
            sum += Factorial(i)
        Next
        Label1.Text = sum
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim input As Integer
        Dim len = TextBox1.Text.Length
        Dim maxnum, minnum As Integer
        input = CInt(TextBox1.Text)
        Dim digits(0 To len - 1) As Integer
        For i = 0 To len - 1
            digits(i) = input Mod 10
            input \= 10
        Next

        maxnum = max(digits)
        minnum = min(digits)
        Label1.Text = "最大數 = " & maxnum & "最小數 = " & minnum & "總和" & maxnum + minnum
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim input As Integer
        input = CInt(TextBox1.Text)
        Dim maxans As Integer = 0
        For i = 1 To input
            If (isprime(i) And input Mod i = 0) Then
                maxans = i
            End If
        Next
        Label1.Text = maxans
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'oct
        Dim input As Integer
        Dim base As Integer = 8
        Dim digits(100) As Integer
        Dim counter As Integer = 0
        input = CInt(TextBox1.Text)
        Do While base < input
            base *= 8
        Loop
        base /= 8 '4096

        Do While base <> 1
            digits(counter) = input \ base
            counter += 1
            input = input - ((input \ base) * base)
            base /= 8
        Loop
        digits(counter) = input / 1
        'Label1.Text &= counter
        For i = 0 To counter
            Label1.Text &= digits(i)
        Next
        Label1.Text &= "<br>"
    End Sub
End Class
