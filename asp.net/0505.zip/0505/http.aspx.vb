﻿
Partial Class http
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim url As String
        url = TextBox1.Text
        'Server.Transfer(url) 錯誤
        Response.Redirect(url)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Response.Write("test")
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'ServerVariables 集合物件的 PATH_INFO 參數取得 ASP.NET 檔案的虛擬路徑， 然後配合
        'Server.MapPath() 方法轉換成實際路徑
        Label1.Text = Request.ServerVariables(TextBox2.Text) & "<br>"

        Label1.Text &= Server.MapPath(Request.ServerVariables("PATH_INFO"))
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Const br = "<br/>"
        Dim hbc As HttpBrowserCapabilities = Request.Browser
        Label1.Text = "browser type:" & hbc.Type & br
        Label1.Text &= "browser name:" & hbc.Browser & br
        Label1.Text &= "version:" & hbc.Version & br
        Label1.Text &= "main version:" & hbc.MajorVersion & br
        Label1.Text &= "sub version:" & hbc.MinorVersion & br
        Label1.Text &= "platform:" & hbc.Platform & br
        Label1.Text &= "supporting frame:" & hbc.Frames & br
        Label1.Text &= "supporting tables:" & hbc.Tables & br
        Label1.Text &= "supporting cookies:" & hbc.Cookies & br
        Label1.Text &= "supporting VBScript:" & hbc.VBScript & br
        Label1.Text &= "supporting JS:" & hbc.JavaScript & br
        Label1.Text &= "supporting JApplets:" & hbc.JavaApplets & br
        Label1.Text &= "supporting ActiveX control:" & hbc.ActiveXControls & br
    End Sub
End Class
