﻿
Partial Class tryexception
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Double = Convert.ToDouble(TextBox1.Text)
        Dim b As Double = Convert.ToDouble(TextBox2.Text)
        Dim ans As Double
        Try
            ' 先檢查 b 是否為 0，避免發生除零錯誤
            If b = 0 Then
                Throw New DivideByZeroException
            End If

            ans = a / b
        Catch ex As DivideByZeroException
            Label1.Text &= ex.ToString() & "<br/>"
        Catch ex As Exception
            Label1.Text &= "一般例外: " & ex.ToString() & "<br/>"
        Finally
            Label1.Text &= "測試值 a=" & a & "<br/>"
            Label1.Text &= "測試值 b=" & b & "<br/>"
        End Try

    End Sub
End Class
