﻿
Partial Class validationSummary
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Page.IsValid Then
            label1.text = "name:" & TextBox1.Text & "ps" & TextBox2.Text
        End If
    End Sub
End Class
